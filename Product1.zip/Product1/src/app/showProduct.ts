import { Component } from "@angular/core";
import {ProductService} from './app.productService';

@Component({
    selector:'show-app',
    templateUrl:'show.product.html'
})

export class showProduct{
    constructor(private prodservice:ProductService){}
    prod:any={};
    prodAll:any[];
    ngOnInit(){
        this.prodservice.getAllProduct().subscribe((data:any)=>this.prodAll=data);
   }
}