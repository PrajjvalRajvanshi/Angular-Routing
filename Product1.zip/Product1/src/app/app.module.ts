﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HttpClientModule } from '@angular/common/http';
import {AddProduct} from './app.addProduct';
import {showProduct} from './showProduct';
import { FormsModule, FormBuilder, FormGroup }from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
const router:Routes=[
    {path:'add',component:AddProduct},
    {path:'show',component:showProduct}
]



@NgModule({
    imports: [
        BrowserModule,HttpClientModule,FormsModule,RouterModule.forRoot(router)
        
    ],
    declarations: [
        AppComponent,AddProduct,showProduct
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }