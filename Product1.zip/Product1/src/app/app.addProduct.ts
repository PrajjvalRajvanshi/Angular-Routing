import {Component,OnInit} from '@angular/core';
import {ProductService} from './app.productService';
@Component({
    selector:'add-prod',
    templateUrl:'add.product.html'
})

export class AddProduct {
    constructor(private prodservice:ProductService){}
    prod:any={};
    addProduct():any{
        //alert(this.prod.prodId + " " + this.prod.prodName);
        this.prodservice.addProduct(this.prod).subscribe((data)=>console.log(data));
    }
}